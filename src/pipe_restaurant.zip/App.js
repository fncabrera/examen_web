import React from "react";
import "./styles.css";
import Restaurant from "./components/Restaurant";

export default function App() {
  return (
    <div className="App">
      <h2>Restaurante Examen</h2>
      <Restaurant />
    </div>
  );
}
