import React, { useState, useCallback, useEffect } from 'react';
import Mesa from "./Mesa";
import Pedido from "./Pedido"

function Restaurant() {
  const [idMesa, setIdMesa] = useState(100);
  const [cantidadPedido, setCantidadPedido] = useState(0);
  const [estadoMesas, setEstadoMesas] = useState([false, false, false, false, false, false, false, false]);
  const [ingresos, setIngresos] = useState([0, 0, 0, 0, 0, 0, 0, 0]);
  const [ingresosAcum, setIngresosAcum] = useState([0, 0, 0, 0, 0, 0, 0, 0]);
  const [ventaDiaria, setVentaDiaria] = useState(0);
  const [abierto, setAbierto] = useState(true);

  function creaMesas() {
    var mesas = [];
    // para crear las primeras 4 de 4 personas, despues otras 4 más de 8 personas
    // el estado indica si esta ocupada o no
    for (var i = 0; i < 4; i++) {
      mesas.push(<Mesa id={i} key={i} numero={i} cantidad={4} menu={seleccionMesa} estado={estadoMesas[i]} total={ingresos[i]} totalAcum={ingresosAcum[i]}/>);
    }
    for (var j = 4; j < 8; j++) {
      mesas.push(<Mesa id={j} key={j} numero={j} cantidad={8} menu={seleccionMesa} estado={estadoMesas[j]} total={ingresos[j]} totalAcum={ingresosAcum[j]}/>);
    }
    return mesas;
  }

  var mesas = creaMesas()


  function seleccionMesa(id) {
    setIdMesa(id);
    if (id <= 3) {
      setCantidadPedido(4)
    } else if (id <= 8) {
      setCantidadPedido(8)
    } else {
      setCantidadPedido(0)
    }
  }

  function hacerPedido(ingreso, idMesa, cantidad) {
    setIdMesa(100);
    setCantidadPedido(0);
    var aux_ingresos = ingresos;
    aux_ingresos[idMesa] = ingreso;
    setIngresos(aux_ingresos);

    var aux_estados_mesas = estadoMesas;
    aux_estados_mesas[idMesa] = true;
    setEstadoMesas(aux_estados_mesas);
  }

  function cerrarMesa(ingreso, idMesa, cierra) {
    setIdMesa(100);
    setCantidadPedido(0);
    //si cierra es false es pq cancelaron el pedido
    if (cierra) {
      setVentaDiaria(ventaDiaria + ingreso);
      var aux_ingresosAcum = ingresosAcum;
      aux_ingresosAcum[idMesa] = aux_ingresosAcum[idMesa] + ingreso;
      setIngresosAcum(aux_ingresosAcum);
    }
    var aux_ingresos = ingresos;
    aux_ingresos[idMesa] = 0;
    setIngresos(aux_ingresos);

    var aux_estados_mesas = estadoMesas;
    aux_estados_mesas[idMesa] = false;
    setEstadoMesas(aux_estados_mesas);

  }

  function cerrarLocal() {
    estadoMesas.forEach((estado, indice, array) => 
      {if (estado) {
        cerrarMesa(ingresos[indice], indice, true)
      }
      var aux_estados_mesas = estadoMesas;
      aux_estados_mesas[indice] = 0;
      setEstadoMesas(aux_estados_mesas);
    })
    setAbierto(false);
  }

  function abrirLocal() {
    setIngresos([0, 0, 0, 0, 0, 0, 0, 0]);
    setIngresosAcum([0, 0, 0, 0, 0, 0, 0, 0]);
    setEstadoMesas([false, false, false, false, false, false, false, false]);
    setAbierto(true);
    setVentaDiaria(0);
  }

  return (
    <div>
      <p>Ventas Diarias Totales: {ventaDiaria}</p>
      <button onClick={abrirLocal}>Abrir Local</button> <button onClick={cerrarLocal}>Cerrar Local</button>
      <div className="flex-container4">
        {mesas.slice(0,4)}
      </div>
      <div className="flex-container8">
        {mesas.slice(4,8)}
      </div>

      <div className="flex-menu">
        <div className="menu">
          {abierto && (
          <Pedido idMesa={idMesa} cantidadPedido={cantidadPedido} estado={estadoMesas[idMesa]} confirmar={hacerPedido} cerrarMesa={cerrarMesa} />
          )}
          {!abierto && (
            <h2>Restaurante Cerrado</h2>
          )}
          </div>
      </div>
      
      
      
    </div>
  );
}

export default Restaurant;
